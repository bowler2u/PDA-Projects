package com.example.homefolder.medi_app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class timeselect extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timeselect);

        SharedPreferences myPref = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = myPref.edit();

        TextView dateChosen = (TextView)findViewById(R.id.dateChosen);
        dateChosen.setText(myPref.getString("date", ""));
    }


    public void onClick(View v) {
        SharedPreferences myPref = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = myPref.edit();
            TextView time1 = (TextView)findViewById(R.id.time1);
            TextView time2 = (TextView) findViewById(R.id.time2);
            TextView time3 = (TextView) findViewById(R.id.time3);
            TextView time4 = (TextView) findViewById(R.id.time4);
            TextView time5 = (TextView) findViewById(R.id.time5);
            TextView time6 = (TextView) findViewById(R.id.time6);
            TextView time7 = (TextView) findViewById(R.id.time7);
            TextView time8 = (TextView) findViewById(R.id.time8);
            TextView time9 = (TextView) findViewById(R.id.time9);
            TextView time10 = (TextView) findViewById(R.id.time10);
            TextView time11= (TextView) findViewById(R.id.time11);
            TextView time12= (TextView) findViewById(R.id.time12);
            TextView time13 = (TextView) findViewById(R.id.time13);
            TextView time14 = (TextView) findViewById(R.id.time14);

        Intent success = new Intent(this, success.class);

            switch (v.getId()) {
                case R.id.time1:
                    String myTime1 = (time1.getText().toString());
                    editor.putString("time", myTime1 ).commit();
                    startActivity(success);
                    break;
                case R.id.time2:
                    String myTime2 = (time2.getText().toString());
                    editor.putString("time", myTime2 ).commit();
                    startActivity(success);
                    break;
                case R.id.time3:
                    String myTime3 = (time3.getText().toString());
                    editor.putString("time", myTime3 ).commit();
                    startActivity(success);
                    break;
                case R.id.time4:
                    String myTime4 = (time4.getText().toString());
                    editor.putString("time", myTime4 ).commit();
                    startActivity(success);
                    break;
                case R.id.time5:
                    String myTime5 = (time5.getText().toString());
                    editor.putString("time", myTime5 ).commit();
                    startActivity(success);
                    break;
                case R.id.time6:
                    String myTime6 = (time6.getText().toString());
                    editor.putString("time", myTime6 ).commit();
                    startActivity(success);
                    break;
                case R.id.time7:
                    String myTime7 = (time7.getText().toString());
                    editor.putString("time", myTime7 ).commit();
                    startActivity(success);
                    break;
                case R.id.time8:
                    String myTime8 = (time8.getText().toString());
                    editor.putString("time", myTime8 ).commit();
                    startActivity(success);
                    break;
                case R.id.time9:
                    String myTime9 = (time9.getText().toString());
                    editor.putString("time", myTime9 ).commit();
                    startActivity(success);
                    break;
                case R.id.time10:
                    String myTime10 = (time10.getText().toString());
                    editor.putString("time", myTime10 ).commit();
                    startActivity(success);
                    break;
                case R.id.time11:
                    String myTime11 = (time11.getText().toString());
                    editor.putString("time", myTime11 ).commit();
                    startActivity(success);
                    break;
                case R.id.time12:
                    String myTime12 = (time12.getText().toString());
                    editor.putString("time", myTime12 ).commit();
                    startActivity(success);
                    break;
                case R.id.time13:
                    String myTime13 = (time13.getText().toString());
                    editor.putString("time", myTime13 ).commit();
                    startActivity(success);
                    break;
                case R.id.time14:
                    String myTime14 = (time14.getText().toString());
                    editor.putString("time", myTime14 ).commit();
                    startActivity(success);
                    break;
            }
        }



}
