package com.example.homefolder.medi_app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.widget.CalendarView;
import android.widget.TextView;

import java.util.Date;
import java.util.Locale;

public class Calendar extends AppCompatActivity {

    CalendarView myCalendar;
    TextView textView;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        //Set Todays Date on the Calendar
        String today = new SimpleDateFormat("dd-mm-yyyy", Locale.getDefault()).format(new Date());
        //display(today);

        myCalendar = (CalendarView)findViewById(R.id.calendar);
        myCalendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {

            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int dayOfMonth) {
                String date = dayOfMonth + "-" + (month+1) + "-" + year;
                //display(date);
                confirmDate(date);
            }


        });


    }



    public void confirmDate(String date){
        SharedPreferences myPref = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = myPref.edit();
        editor.putString("date", date).commit();

        Intent timeselect = new Intent(this, timeselect.class);
        startActivity(timeselect);




    }
}
