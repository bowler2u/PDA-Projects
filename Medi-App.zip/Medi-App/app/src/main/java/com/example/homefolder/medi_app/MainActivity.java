package com.example.homefolder.medi_app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int num;
    CardView cv1;
    CardView cv2;
    CardView cv3;
    CardView cv4;
    CardView cv5;
    TextView appointment1;
    TextView appointment2;
    TextView appointment3;
    TextView appointment4;
    TextView appointment5;
    TextView appointmentT1;
    TextView appointmentT2;
    TextView appointmentT3;
    TextView appointmentT4;
    TextView appointmentT5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SharedPreferences myPref = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = myPref.edit();

        // Int numKey is the Value of what Doctor was Selected ( 1-5 )
        num = myPref.getInt("numKey", 0);

        // Int CardKey is a count that will keep track of how many saved appointments there is, controls what CardView to populate
        int cardCount = myPref.getInt("cardKey", 0);

        // If there is no int value saved to a shared Preferences value from the doctor selection screen, DO NOTHING

        if(cardCount != 0) {
            setInfo(cardCount);
            checkVisibility();
            init();
        }

    }



    public void init(){
        SharedPreferences myPref = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = myPref.edit();

        appointment1 = (TextView)findViewById(R.id.doc1);
        appointmentT1 = (TextView)findViewById(R.id.date1);
        appointment2 = (TextView)findViewById(R.id.doc2);
        appointmentT2 = (TextView)findViewById(R.id.date2);
        appointment3 = (TextView)findViewById(R.id.doc3);
        appointmentT3 = (TextView)findViewById(R.id.date3);
        appointment4 = (TextView)findViewById(R.id.doc4);
        appointmentT4 = (TextView)findViewById(R.id.date4);
        appointment5 = (TextView)findViewById(R.id.doc5);
        appointmentT5 = (TextView)findViewById(R.id.date5);

        appointment1.setText(myPref.getString("1stSelection", ""));
        appointmentT1.setText(myPref.getString("1stDateSelection", ""));
        appointmentT1.append(" @ ");
        appointmentT1.append(myPref.getString("1stTimeSelection", ""));

        appointment2.setText(myPref.getString("2ndSelection", ""));
        appointmentT2.setText(myPref.getString("2ndDateSelection", ""));
        appointmentT2.append(" @ ");
        appointmentT2.append(myPref.getString("2ndTimeSelection", ""));

        appointment3.setText(myPref.getString("3rdSelection", ""));
        appointmentT3.setText(myPref.getString("3rdDateSelection", ""));
        appointmentT3.append(" @ ");
        appointmentT3.append(myPref.getString("3rdTimeSelection", ""));

        appointment4.setText(myPref.getString("4thSelection", ""));
        appointmentT4.setText(myPref.getString("4thDateSelection", ""));
        appointmentT4.append(" @ ");
        appointmentT4.append(myPref.getString("4thTimeSelection", ""));

        appointment5.setText(myPref.getString("5thSelection", ""));
        appointmentT5.setText(myPref.getString("5thDateSelection", ""));
        appointmentT5.append(" @ ");
        appointmentT5.append(myPref.getString("5thTimeSelection", ""));




    }

    // Write a function to check if a boolean value is true, and if it is, Set the visibility of Cardview to Visible
    public void checkVisibility(){
        SharedPreferences myPref = PreferenceManager.getDefaultSharedPreferences(this);
        boolean checkCv1 = myPref.getBoolean("cv1", false);
        boolean checkCv2 = myPref.getBoolean("cv2", false);
        boolean checkCv3 = myPref.getBoolean("cv3", false);
        boolean checkCv4 = myPref.getBoolean("cv4", false);
        boolean checkCv5 = myPref.getBoolean("cv5", false);
        cv1 = (CardView)findViewById(R.id.card1);
        cv2 = (CardView)findViewById(R.id.card2);
        cv3 = (CardView)findViewById(R.id.card3);
        cv4 = (CardView)findViewById(R.id.card4);
        cv5 = (CardView)findViewById(R.id.card5);

        if (checkCv1) {
            cv1.setVisibility(View.VISIBLE);
        }
        if (checkCv2) {
            cv2.setVisibility(View.VISIBLE);
        }
        if (checkCv3) {
            cv3.setVisibility(View.VISIBLE);
        }
        if (checkCv4) {
            cv4.setVisibility(View.VISIBLE);
        }
        if (checkCv5) {
            cv5.setVisibility(View.VISIBLE);
        }
    }

    public void setInfo(int cardCount){
        // Access the Shared Preferences Memory
        SharedPreferences myPref = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = myPref.edit();
        cv1 = (CardView)findViewById(R.id.card1);
        cv2 = (CardView)findViewById(R.id.card2);
        cv3 = (CardView)findViewById(R.id.card3);
        cv4 = (CardView)findViewById(R.id.card4);
        cv5 = (CardView)findViewById(R.id.card4);

        num = myPref.getInt("numKey", 0);
        String selection = myPref.getString(("selection" + num), "");
        String date = myPref.getString("date", "");
        String time = myPref.getString("time", "");

        //if the function called has a parameter value of 1, Fill Card one with the info
        if(cardCount == 1) {
            editor.putBoolean("cv1", true);
            editor.putString("1stSelection", selection);
            editor.putString("1stDateSelection", date);
            editor.putString("1stTimeSelection", time);
            editor.commit();
        }

        // If the function called has a value of 2, Fill Card Two with the info
        if(cardCount == 2) {
            editor.putBoolean("cv2", true);
            editor.putString("2ndSelection", selection);
            editor.putString("2ndDateSelection", date);
            editor.putString("2ndTimeSelection", time);
            editor.commit();
        }

        //if the function called has a parameter value of 3, Fill Card one with the info
        if(cardCount == 3) {
            editor.putBoolean("cv3", true);
            editor.putString("3rdSelection", selection);
            editor.putString("3rdDateSelection", date);
            editor.putString("3rdTimeSelection", time);
            editor.commit();

        }

        // If the function called has a value of 4, Fill Card Two with the info
        if(cardCount == 4) {
            editor.putBoolean("cv4", true);
            editor.putString("4thSelection", selection);
            editor.putString("4thDateSelection", date);
            editor.putString("4thTimeSelection", time);
            editor.commit();
        }
        if(cardCount == 5) {
            editor.putBoolean("cv5", true);
            editor.putString("5thSelection", selection);
            editor.putString("5thDateSelection", date);
            editor.putString("5thTimeSelection", time);
            editor.commit();
        }



    }


    public void newApp(View view){

        Intent newAppointment = new Intent(this,SelectDocActivity.class);
        startActivity(newAppointment);
    }
}
