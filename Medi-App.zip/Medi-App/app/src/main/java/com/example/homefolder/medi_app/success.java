package com.example.homefolder.medi_app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class success extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success);
        SharedPreferences myPref = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = myPref.edit();

        TextView time = (TextView)findViewById(R.id.time);
        TextView day = (TextView)findViewById(R.id.day);
        TextView doctor = (TextView)findViewById(R.id.doctor);

        int num = myPref.getInt("numKey", 0);
        String selection = myPref.getString(("selection" + num), "");

        day.setText(myPref.getString("date", ""));
        time.setText("@ ");
        time.append(myPref.getString("time", ""));
        doctor.setText("With ");
        doctor.append(selection);

    }

    public void onClick(View v){
        Intent main = new Intent(this, MainActivity.class);

        startActivity(main);

    }

}
