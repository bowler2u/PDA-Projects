package com.example.homefolder.medi_app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class SelectDocActivity extends AppCompatActivity {
    int Count;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);
        SharedPreferences myPref = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = myPref.edit();
        Count = myPref.getInt("cardKey", 0);

    }


    public void setDoc1(View view) {
        setDoc(1);
    }public void setDoc2(View view) {
        setDoc(2);
    }public void setDoc3(View view) {
        setDoc(3);
    }public void setDoc4(View view) {
        setDoc(4);
    }public void setDoc5(View view) {
        setDoc(5);
    }


    public void setDoc(int num) {
        Count++;

        Intent setDate = new Intent(this, Calendar.class);
        //Intent setDoc = new Intent(this, MainActivity.class);

        SharedPreferences myPref = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = myPref.edit();
        //Defining and Saving all TextView Text values to a Selection#
        TextView doc1 = (TextView) findViewById(R.id.doc1Name);
        editor.putString("selection1", doc1.getText().toString());
        TextView doc2 = (TextView) findViewById(R.id.doc2Name);
        editor.putString("selection2", doc2.getText().toString());
        TextView doc3 = (TextView) findViewById(R.id.doc3Name);
        editor.putString("selection3", doc3.getText().toString());
        TextView doc4 = (TextView) findViewById(R.id.doc4Name);
        editor.putString("selection4", doc4.getText().toString());
        TextView doc5 = (TextView) findViewById(R.id.doc5Name);
        editor.putString("selection5", doc5.getText().toString());


        switch (num) {
            case 1:
                // Assigning our numKey value 1
                editor.putInt("numKey", num);
                //Assigning our cardKey value 1
                editor.putInt("cardKey", Count);

                editor.commit();
                startActivity(setDate);

                break;

            case 2:
                //Save numKey value to 2
                editor.putInt("numKey", num);
                //Update the Count
                editor.putInt("cardKey", Count);

                editor.commit();
                startActivity(setDate);

                break;
            case 3:
                editor.putInt("numKey", num);
                //Update the Count
                editor.putInt("cardKey", Count);

                editor.commit();
                startActivity(setDate);

                break;
            case 4:
                editor.putInt("numKey", num);
                editor.putInt("cardKey", Count);

                editor.commit();
                startActivity(setDate);

                break;
            case 5:
                editor.putInt("numKey", num);
                editor.putInt("cardKey", Count);

                editor.commit();
                startActivity(setDate);

                break;

        }
    }

}
